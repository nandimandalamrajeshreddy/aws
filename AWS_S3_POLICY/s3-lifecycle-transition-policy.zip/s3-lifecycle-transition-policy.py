import logging
import boto3
from botocore.exceptions import ClientError

import json

lifecycle_config_settings = {
    'Rules': [
    {
      'Expiration': {
        'Days': 366
      },
      'ID': 'CostOpt-S3-lifeCycle-policy',
      'Filter': {},
      'Status': 'Enabled',
      'Transitions': [
        {
          'Days': 30,
          'StorageClass': 'STANDARD_IA'
        },
        {
          'Days': 60,
          'StorageClass': 'INTELLIGENT_TIERING'
        },
        {
          'Days': 90,
          'StorageClass': 'ONEZONE_IA'
        },
        {
          'Days': 120,
          'StorageClass': 'GLACIER'
        },
        {
          'Days': 365,
          'StorageClass': 'DEEP_ARCHIVE'
        }
      ],
      'NoncurrentVersionTransitions': [
        {
          'NoncurrentDays': 30,
          'StorageClass': 'STANDARD_IA'
        },
        {
          'NoncurrentDays': 60,
          'StorageClass': 'INTELLIGENT_TIERING'
        },
        {
          'NoncurrentDays': 90,
          'StorageClass': 'ONEZONE_IA'
        },
        {
          'NoncurrentDays': 120,
          'StorageClass': 'GLACIER'
        },
        {
          'NoncurrentDays': 365,
          'StorageClass': 'DEEP_ARCHIVE'
        }
      ],
      'NoncurrentVersionExpiration': {
        'NoncurrentDays': 366
      },
      'AbortIncompleteMultipartUpload': {
        'DaysAfterInitiation': 60
      }
    }
  ]}

def put_bucket_lifecycle_configuration(bucket_name, lifecycle_config):
    """Set the lifecycle configuration of an Amazon S3 bucket

    :param bucket_name: string
    :param lifecycle_config: dict of lifecycle configuration settings
    :return: True if lifecycle configuration was set, otherwise False
    """

    # Set the configuration
    s3 = boto3.client('s3')
    try:
        s3.put_bucket_lifecycle_configuration(Bucket=bucket_name,
                                              LifecycleConfiguration=lifecycle_config)
    except ClientError as e:

        return False
    return True

def lambda_handler(event, context):
    # TODO implement
    test_bucket_name = event.get('detail').get('requestParameters').get('bucketName')
    print(event)
    print(event.get('detail').get('requestParameters').get('bucketName'))

    success = put_bucket_lifecycle_configuration(test_bucket_name,lifecycle_config_settings)

    if success:
    #  logging.info('The lifecycle configuration was set for {test_bucket_name}')
        print('The lifecycle configuration was set for {test_bucket_name}')