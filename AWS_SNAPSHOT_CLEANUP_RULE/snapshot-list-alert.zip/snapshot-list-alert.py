import json
import boto3
import os
import datetime
from datetime import timedelta


def lambda_handler(event, context):
   
    # Parameterize all the hard code values and accept the values from environment variables
    backup_days = int(os.environ['BACKUP_DAYS'])
    sns_topic = os.environ.get('SNS_TOPIC')
    snap_delete_time = int(os.environ.get('SNAP_DELETE_TIME'))
    client = boto3.client('ec2')
    sns_client = boto3.client("sns")
    a = 1
    
    #Calculate the current time and to_be_deleted_time for a snapshot based on snap_time mentioned in the environment variable
    current_time = datetime.datetime.now().date()
    tobedeletedby_time = current_time + timedelta(days=snap_delete_time)
    tobedeletedbystring = str(tobedeletedby_time)
    current_timestring = str(current_time)

    # Declare an empty list which will store the snapshots tagged and scheduled for deletion
    deletionlist = []
    # Declare the mail body for the email alert notification
    mail_body = ''
    dottedline = "================================================================================="
    
    # Itertaing through the loop for all the regions in order to identify snapshots and tag them for deletion
    for region in client.describe_regions()['Regions']:
        ec2_con_re=boto3.resource(service_name="ec2",region_name=region['RegionName'])
        ec2_client=boto3.client(service_name="ec2",region_name=region['RegionName'])
        sts_con_cli=boto3.client(service_name="sts",region_name=region['RegionName'])
        response=sts_con_cli.get_caller_identity()
        my_own_id=response.get('Account')
     
        # Fetching the list of snapshots for the particular region for the particular account
        snapshotslist=ec2_con_re.snapshots.filter(OwnerIds=[my_own_id])

    	# Creating the list for the snapshots to be deleted based on the time difference between the creation and to be deleted time
        for snap in ec2_con_re.snapshots.filter(OwnerIds=[my_own_id]):
            # Fetch the id of the snapshot
            snapshot_id=snap.id
            skip_flag = 0
            test_substring = 'Created by CreateImage(i-'
            if(len(snap.description) > 0): 
                if test_substring in snap.description:
                    skip_flag=1
 
                
    		# Get the creation time of the snapshot		
            creation_time = snap.start_time.date()
    
            # Calculate the difference between the current and creation time of the snapshot 	
            diff_time = (current_time - creation_time).days
            
    		# If the time difference is greater than the backup_days, then add the "TO_BE_DELETED_BY" tags to the snapshot

            if(diff_time > backup_days):
                try:
    				# Fetch the resource_tags for the current snapshot.Add the tags TO_BE_DELETED_BY and add the snapshot to deletion list
                    if snap.tags == None:
                        resource_tags =[]
                    else:
                        resource_tags = snap.tags
                    
                    region_name=region['RegionName']
                    # Check the condition if the "BASEINFRA" and "aws:backup:source-resource" tags are not present in the resource_tags for the snapshot
                    if 'BASEINFRA' not in [resource_tag['Key'] for resource_tag in resource_tags]:
                        if 'aws:backup:source-resource' not in [resource_tag['Key'] for resource_tag in resource_tags]:
                            if(skip_flag == 0 ):
                                # Check the condition if the "TO_BE_DELETED_BY" tag is not present in the resource_tags for the snapshot. This is to prevent the "TO_BE_DELETED_BY" from getting overwritten
                                if 'TO_BE_DELETED_BY' not in [resource_tag['Key'] for resource_tag in resource_tags]:
                                    # If the above 2 conditions are met, then add the "TO_BE_DELETED_BY" tag with the value as tobedeletedbystring
                                    ec2_con_re.create_tags(Resources=[snapshot_id, ], Tags=[{'Key': 'TO_BE_DELETED_BY', 'Value': tobedeletedbystring}, ])
                                    region_name=region['RegionName']
                                    snapshot_id = str(a) + ".  "  + snapshot_id + "  in region   --->  " + region_name
                                    a = a + 1
                                    # Adding the snapshot to the deletion list
                                    deletionlist.append(snapshot_id)
                except:
                    continue

    # Composing the email for snapshot deletion alert 
    mail_body = mail_body + 'Hi All,' + ' \n' + ' \n' + 'Please find the below list of noncompliant snapshots which are on AWS,and are scheduled for deletion.'  + ' \n' + ' \n' + 'Kindly contact the admin or add or remove relevant tag on the resource if you want to retain .' + ' \n' + ' \n' +  dottedline + ' \n'+ ' \n' + ' \n'.join(deletionlist) + ' \n' + ' \n'+ dottedline  + ' \n' + ' \n'+ '******* This is an autogenerated Email from an unmonitored mail box , please do not reply *******'

	# Sending email notifications for snapshot list alerts 
    response = sns_client.publish(
        TopicArn = sns_topic,
        Message = mail_body,
        Subject = '***ALERT*** Snapshots to be DELETED from AWS'
    )